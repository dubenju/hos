#ifndef __MBR_H_
#define __MBR_H_

#ifdef __cpluscplus
extern "C" {
#endif

typedef struct _DPT1 {
    char DPT_Flg;
    char DPT_start_chs[3];
    char DPT_filesystem;
    char DPT_end_chs[3];
    char DPT_start_sec[4];
    char DPT_sec_cnt[4];
} dpt, * pdpt;

typedef struct _MBR1 {
    char Code[440];
    char Selected[4];
    char Reserved[2];
    dpt  dpt_item[4];
    char end_flag[2];
} mbr, *pmbr;

#ifdef __cpluscplus
}
#endif

#endif // __MBR_H_
