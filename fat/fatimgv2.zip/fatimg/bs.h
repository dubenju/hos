#ifndef __BS_H_
#define __BS_H_

#ifdef __cpluscplus
extern "C" {
#endif

typedef struct _BS {
    char BS_jmpBoot[3];
    char BS_OEMName[8];
    char BPB_BytesPerSec[2];
    char BPB_SecPerClus;
    char BPB_RsvdSecCnt[2];
    char BPB_NumFATs;
    char BPB_RootEntCnt[2];
    char BPB_ToSec16[2];
    char BPB_Media;
    char BPB_FATz16[2];
    char BPB_SecPerTrk[2];
    char BPB_NumHeads[2];
    char BPB_HidSec[4];
    char BPB_ToSec32[4];
    char BS_DrvNum;
    char BS_Reserved1;
    char BS_BootSig;
    char BS_VolID[4];
    char BS_VolLab[11];
    char BS_FileSysType[8];
    char BS_Code[448];
    char BS_EndFlag[2];
} bs, *pbs;

#ifdef __cpluscplus
}
#endif

#endif // __BS_H_
