#ifndef __FDT_H_
#define __FDT_H_

#ifdef __cplusplus
extern "C" {
#endif

typedef struct _FDTEntery {
    char name[8];
    char ex_name[3];
    char attr;
    char resaved;
    char crt_time_ms;
    char crt_tm[2];
    char crt_dt[2];
    char lst_acs_dt[2];
    char idx[2];
    char lst_mod_tm[2];
    char lst_mod_dt[2];
    char st_clus[2];
    char f_size[4];
} fdt, * pfdt;

#ifdef __cplusplus
}
#endif
#endif // __FDT_H
