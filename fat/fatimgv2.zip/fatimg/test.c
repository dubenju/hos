#include <stdio.h>
#include "mbr.h"
#include "bs.h"
#include "fdt.h"

#define MAX_IN_FILE 100
#define READ_BYTE   512
#define BOOT_SECTOR_BYTE 512

typedef struct _cmd_line_info {
    char * mbr_file_name;
    char * bts_file_name;
    int in_file_cnt;
    char * in_file_name[MAX_IN_FILE];
    long in_file_size[MAX_IN_FILE];
    long filler_size[MAX_IN_FILE];
    char * out_file_name;
} cmdline_info, *p_cmdline_info;

void show_usage(const char * pgm);
int main_proc(p_cmdline_info info);
void get_env_info();
char * upper(char * obj, const char * src);

int main(int argc, char **argv) {
    int i;
    char flg;
    int slen;
    int ssize;
    int offset;
    p_cmdline_info pinfo;

    i = 0;
    flg = 0;
    slen = 0;
    ssize = 0;
    offset = 0;
    pinfo = NULL;

    get_env_info();
    printf("%s.\r\n", argv[0]);

    if (argc == 1) {
        show_usage(argv[0]);
        return -1;
    }
    pinfo =(p_cmdline_info) malloc(sizeof(cmdline_info));
    if (pinfo == NULL) {
        printf("cmd line memory alloc error.\r\n");
        return -1;
    }
    pinfo->in_file_cnt = -1;
    pinfo->mbr_file_name = NULL;
    pinfo->bts_file_name = NULL;
    pinfo->out_file_name = NULL;
    for (i = 0; (flg == 0 && i < argc); i ++) {
        /* printf("%d %s %d.\r\n", i, argv[i], pinfo->in_file_cnt); */
        if (memcmp(argv[i], "-i", 2) == 0) {
            slen = 0;
            offset = 0;
            pinfo->in_file_cnt ++;
            if (pinfo->in_file_cnt >= MAX_IN_FILE) {
                printf("input file's count over.MAX=%d.\r\n", MAX_IN_FILE);
                flg = 1;
                break;
            }
            /* input file's name */
            if (strlen(argv[i]) == 2) {
                i ++;
                if (i >= argc) {
                    printf("input file's name error.\r\n");
                    flg = 1;
                    break;
                }
                /* debug printf("%d %s.\r\n", i, argv[i]); */
                if (argv[i][0] == '-') {
                    /* none error pgm -i - */
                }
                slen = strlen(argv[i]);
            } else {
                slen = strlen(argv[i]) - 2;
                offset = 2;
            }
            ssize = (slen + 1) * sizeof(char);
            pinfo->in_file_name[pinfo->in_file_cnt] = (char *) malloc(ssize);
            if (pinfo->in_file_name[pinfo->in_file_cnt] == NULL) {
                printf("input file%d name memory alloc erro.\r\n", i);
                flg = 1;
                break;
            }
            memset(pinfo->in_file_name[pinfo->in_file_cnt], 0, ssize);
            memcpy(pinfo->in_file_name[pinfo->in_file_cnt], argv[i] + offset, slen);
            printf("  [info]   input file %02d: %s.\r\n", (pinfo->in_file_cnt + 1), pinfo->in_file_name[pinfo->in_file_cnt]);
            pinfo->filler_size[pinfo->in_file_cnt] = 0;
            continue;
        }

        if (memcmp(argv[i], "-o", 2) == 0) {
            slen = 0;
            offset = 0;

            /* output file's name */
            if (strlen(argv[i]) == 2) {
                i ++;
                if (i >= argc) {
                    printf("output file's name error.\r\n");
                    flg = 1;
                    break;
                }
                /* debug printf("%d %s.\r\n", i, argv[i]); */
                if (argv[i][0] == '-') {
                    /* none error pgm -i - */
                }
                slen = strlen(argv[i]);
            } else {
                slen = strlen(argv[i]) - 2;
                offset = 2;
            }
            ssize = (slen + 1) * sizeof(char);
            pinfo->out_file_name = (char *) malloc(ssize);
            if (pinfo->out_file_name == NULL) {
                printf("output file%d name memory alloc erro.\r\n", i);
                flg = 1;
                break;
            }
            memset(pinfo->out_file_name, 0, ssize);
            memcpy(pinfo->out_file_name, argv[i] + offset, slen);
            printf("  [info]     output file: %s.\r\n", pinfo->out_file_name);
            continue;
        }

        if (memcmp(argv[i], "-b", 2) == 0) {
            slen = 0;
            offset = 0;

            /* boot sector file's name */
            if (strlen(argv[i]) == 2) {
                i ++;
                if (i >= argc) {
                    printf("boot sector file's name error.\r\n");
                    flg = 1;
                    break;
                }
                /* debug printf("%d %s.\r\n", i, argv[i]); */
                if (argv[i][0] == '-') {
                    /* none error pgm -i - */
                }
                slen = strlen(argv[i]);
            } else {
                slen = strlen(argv[i]) - 2;
                offset = 2;
            }
            ssize = (slen + 1) * sizeof(char);
            pinfo->bts_file_name = (char *) malloc(ssize);
            if (pinfo->bts_file_name == NULL) {
                printf("boot sector file%d name memory alloc erro.\r\n", i);
                flg = 1;
                break;
            }
            memset(pinfo->bts_file_name, 0, ssize);
            memcpy(pinfo->bts_file_name, argv[i] + offset, slen);
            printf("  [info]boot sector file: %s.\r\n", pinfo->bts_file_name);
            continue;
        }

        if (memcmp(argv[i], "-m", 2) == 0) {
            slen = 0;
            offset = 0;

            /* mbr file's name */
            if (strlen(argv[i]) == 2) {
                i ++;
                if (i >= argc) {
                    printf("mbr file's name error.\r\n");
                    flg = 1;
                    break;
                }
                /* debug printf("%d %s.\r\n", i, argv[i]); */
                if (argv[i][0] == '-') {
                    /* none error pgm -i - */
                }
                slen = strlen(argv[i]);
            } else {
                slen = strlen(argv[i]) - 2;
                offset = 2;
            }
            ssize = (slen + 1) * sizeof(char);
            pinfo->mbr_file_name = (char *) malloc(ssize);
            if (pinfo->mbr_file_name == NULL) {
                printf("mbr file%d name memory alloc erro.\r\n", i);
                flg = 1;
                break;
            }
            memset(pinfo->mbr_file_name, 0, ssize);
            memcpy(pinfo->mbr_file_name, argv[i] + offset, slen);
            printf("  [info]        mbr file: %s.\r\n", pinfo->mbr_file_name);
            continue;
        }
    }

    if (flg == 0 && pinfo->in_file_cnt == -1) {
        printf("[main]input file's name is need.error\r\n");
        flg = 1;
    }
    if (flg == 0 && pinfo->out_file_name == NULL) {
        printf("[main]output file's is need.error\r\n");
        flg = 1;
    }

    flg = main_proc(pinfo);
    
    if (pinfo != NULL) {
        if (pinfo->mbr_file_name != NULL) {
            free(pinfo->mbr_file_name);
            pinfo->mbr_file_name = NULL;
        }
        if (pinfo->bts_file_name != NULL) {
            free(pinfo->bts_file_name);
            pinfo->bts_file_name = NULL;
        }
        if (pinfo->out_file_name != NULL) {
            free(pinfo->out_file_name);
            pinfo->out_file_name = NULL;
        }
        for (i = 0; i < pinfo->in_file_cnt; i ++) {
            free(pinfo->in_file_name[i]);
            pinfo->in_file_name[i] = NULL;
        }
        pinfo->in_file_cnt = -1;
        free(pinfo);
        pinfo = NULL;
    }
    if (flg == 1) {
        return -1;
    }
    return 0;
}

void show_usage(const char *pgm) {
    printf("Usage: %s parameter.\r\n", pgm);
    return ;
}

int main_proc(p_cmdline_info info) {
    FILE * in;
    FILE * out;
    int flg;
    char * buf;
    int rsize;
    int wsize;
    int i, j;
    pmbr mbrs;
    pbs boots;
    char dbg_msg[256];
    long dbg_num;
    long fat_size;
    long fat_sec;
    long sec_size;
    char * pFAT;
    char num_fat;
    long in_file_sec;
    char sec_per_clus;
    short last_sec;
    char obj_sec[2];
    long fat_idx;
    char fat_flg;
    fdt rfdt;
    short r_ent_cnt;
    long r_ent_size;
    char * pr_ent;
    int pos;
    long disk_sec;
    long disk_size;
    short start_clus;
    char yy;
    char mm;
    char dd;
    char hh;
    char mi;
    char ss;
    char opt_flag;
    long resave_sec_cnt;
    char fat12_flg;
    char fat16_flg;
    char fat32_flg;
    char zero_flg;

    in = NULL;
    out = NULL;
    flg = 0;
    buf = NULL;
    rsize = 0;
    wsize = 0;
    mbrs = NULL;
    boots = NULL;
    dbg_num = 0;
    fat_size = 0;
    fat_sec = 0;
    sec_size = 0;
    pFAT = NULL;
    num_fat = 0;
    in_file_sec = 0;
    sec_per_clus = 0;
    last_sec = 2;
    fat_idx = 0;
    fat_flg = 0;
    r_ent_cnt = 0;
    pr_ent = NULL;
    pos = -1;
    disk_sec = 0;
    disk_size = 0;
    start_clus = 0;
    yy = 0;
    mm = 0;
    dd = 0;
    hh = 0;
    mi = 0;
    ss = 0;
    opt_flag = 0;
    resave_sec_cnt = 0;
    fat12_flg = 0;
    fat16_flg = 0;
    fat32_flg = 0;

    if (info == NULL) {
        printf("parameter error.\r\n");
        flg = 1;
    }

    if (flg == 0 && (info->mbr_file_name == NULL || strlen(info->mbr_file_name) <= 0)) {
        printf("because mbr is none. floppy disk image is creating ...\r\n");
        opt_flag = 0;
    } else if (flg == 0) {
        printf("\r\nbecause mbr is exist. hard disk image is creating ...\r\n");
        opt_flag = 1;
    }
    printf("opt_flag=%d.\r\n\r\n", opt_flag);
    if (flg == 0 && (info->bts_file_name == NULL || strlen(info->bts_file_name) <= 0)) {
        printf("boot sector file's name error.\r\n");
        flg = 1;
    }
    printf("input file's count is %d.\r\n", (info->in_file_cnt + 1));
    if (flg ==0 && (info->in_file_cnt < 0) ) {
        printf("input file's name error.\r\n");
        flg = 1;
    }
    if (flg == 0 && (info->out_file_name == NULL || strlen(info->out_file_name) <= 0)) {
        printf("output file's name error.\r\n");
        flg = 1;
    }
    if (flg == 0 ) {
        out = fopen(info->out_file_name, "wb");
        if (out == NULL) {
            printf("out file open error.\r\n");
            flg = 1;
        }
    }
    if (flg == 0) {
        buf = (char *) malloc(READ_BYTE * sizeof(char));
        if (buf == NULL) {
            printf("read buffer memory alloc error.\r\n");
            flg = 1;
        }
    }
    if (flg == 0 &&opt_flag == 1) {
        mbrs = (pmbr) malloc(sizeof(mbr));
        if (mbrs == NULL) {
            printf("mbr memory alloc error.\r\n");
            flg = 1;
        }
    }

    /* 1.MBR Write */
    if (flg == 0 && opt_flag == 1) {
        in = fopen(info->mbr_file_name, "rb");
        if (in == NULL) {
            printf("mbr file open error.\r\n");
            flg = 1;
        }
    }
    while(opt_flag && !flg && !feof(in)) {
        memset(buf, 0, READ_BYTE * sizeof(char));
        rsize = fread(buf, sizeof(char), READ_BYTE, in);
        printf("rsize=%d.\r\n", rsize);
        if (rsize <= 0) {
            break;
        }
        /* write MBR */
        wsize = fwrite(buf, sizeof(char), rsize, out);
        if (wsize != rsize) {
            printf("MBR write error.\r\n");
            flg = 1;
            break;
        }
        /* save somthing to memory */
        memset(mbrs, 0, sizeof(mbr));
        memcpy(mbrs, buf, rsize);
        printf("====== MBR's Info Begin ======\r\n");
        printf("size:[%d].\r\n", sizeof(mbr));
        for (i = 0; i < 4; i ++) {
            printf("[%d]DPT_Flg      :[%X]\r\n", i, mbrs->dpt_item[i].DPT_Flg);
            printf("[%d]DPT_start_h   :[%X]\r\n", i, mbrs->dpt_item[i].DPT_start_chs[0]);
            printf("[%d]DPT_start_c   :[%X]\r\n", i, mbrs->dpt_item[i].DPT_start_chs[1]);
            printf("[%d]DPT_start_s   :[%X]\r\n", i, mbrs->dpt_item[i].DPT_start_chs[2]);
            printf("[%d]DPT_filesystem:[%X]\r\n", i, mbrs->dpt_item[i].DPT_filesystem);
            printf("[%d]DPT_end_h     :[%X]\r\n", i, mbrs->dpt_item[i].DPT_end_chs[0]);
            printf("[%d]DPT_end_c     :[%X]\r\n", i, mbrs->dpt_item[i].DPT_end_chs[1]);
            printf("[%d]DPT_end_s     :[%X]\r\n", i, mbrs->dpt_item[i].DPT_end_chs[2]);
            dbg_num = 0;
            memcpy(&dbg_num, mbrs->dpt_item[i].DPT_start_sec, 4);
            printf("[%d]DPT_start_sec:[%d]\r\n", i, dbg_num);
            if (mbrs->dpt_item[i].DPT_Flg != 0) {
                resave_sec_cnt = dbg_num - 1;
            }
            printf("resave sector count:%d.\r\n", resave_sec_cnt);
            dbg_num = 0;
            memcpy(&dbg_num, mbrs->dpt_item[i].DPT_sec_cnt, 4);
            printf("[%d]DPT_sec_cnt:[%d]\r\n", i, dbg_num);
        }
        dbg_num = 0;
        memcpy(&dbg_num, mbrs->end_flag, 2);
        printf("Ebd Flg  :[%X]H.\r\n", dbg_num);
        printf("====== MBR'sInfo  End  ======\r\n");
        fat_size = fat_sec * sec_size;
        printf("FAT's size=%d.\r\n", fat_size);
    }
    if (in != NULL) {
        fclose(in);
        in = NULL;
    }

    /* 2.Write Resave sec by mbr's dpt */
    if (flg ==0 && opt_flag == 1) {
        if (resave_sec_cnt > 0) {
            for(j = 0; j < (resave_sec_cnt * BOOT_SECTOR_BYTE); j ++) {
                memset(dbg_msg, 0x00, sizeof(dbg_msg));
                fwrite(dbg_msg, sizeof(char), 1, out);
            }
        }
    }
    if (flg == 0) {
        boots = (pbs) malloc(sizeof(bs));
        if (boots == NULL) {
            printf("boot sector's memory alloc error.\r\n");
            flg = 1;
        }
    }

    /* 3.boot sector file write */
    if (flg == 0) {
        in = fopen(info->bts_file_name, "rb");
        if (in == NULL) {
            printf("boot sector file open error.\r\n");
            flg = 1;
        }
    }
    while(!flg  && !feof(in)) {
        memset(buf, 0, READ_BYTE * sizeof(char));
        rsize = fread(buf, sizeof(char), READ_BYTE, in);
        printf("rsize=%d.\r\n", rsize);
        if (rsize <= 0) {
            break;
        }
        /* write Boot Sector */
        wsize = fwrite(buf, sizeof(char), rsize, out);
        if (wsize != rsize) {
            printf("Boot Sector write error.\r\n");
            flg = 1;
            break;
        }
        /* save somthing to memory */
        memset(boots, 0, BOOT_SECTOR_BYTE * sizeof(char));
        memcpy(boots, buf, rsize);
        printf("====== Boot Sector Info Begin ======\r\n");
        printf("size: [%d].\r\n", sizeof(bs));
        memset(dbg_msg, 0, 256);
        memcpy(dbg_msg, boots->BS_OEMName, 8);
        printf("BS_OEMName       :[%s].\r\n", dbg_msg);
        dbg_num = 0;
        memcpy(&dbg_num, boots->BPB_BytesPerSec, 2);
        printf("BPB_BytesPerCluse:[%d].\r\n", dbg_num);
        sec_size = dbg_num;
        printf("BPB_SecPerClus   :[%d].\r\n", boots->BPB_SecPerClus);
        sec_per_clus = boots->BPB_SecPerClus;
        dbg_num = 0;
        memcpy(&dbg_num, boots->BPB_RsvdSecCnt, 2);
        printf("BPB_RsvdSecCnt   :[%d].\r\n", dbg_num);
        printf("BPB_NumFATs      :[%d].\r\n", boots->BPB_NumFATs);
        num_fat = boots->BPB_NumFATs;
        dbg_num = 0;
        memcpy(&dbg_num, boots->BPB_RootEntCnt, 2);
        printf("BPB_RootEntCnt   :[%d].\r\n", dbg_num);
        r_ent_cnt = (short) dbg_num;
        dbg_num = 0;
        memcpy(&dbg_num, boots->BPB_ToSec16, 2);
        printf("BPB_ToSec16      :[%d].\r\n", dbg_num);
        disk_sec = dbg_num;
        printf("BPB_Media        :[%d].\r\n", boots->BPB_Media);
        dbg_num = 0;
        memcpy(&dbg_num, boots->BPB_FATz16, 2);
        printf("BPB_FATz16       :[%d].\r\n", dbg_num);
        fat_sec = dbg_num;
        dbg_num = 0;
        memcpy(&dbg_num, boots->BPB_SecPerTrk, 2);
        printf("BPB_SecPerTrk    :[%d].\r\n", dbg_num);
        dbg_num = 0;
        memcpy(&dbg_num, boots->BPB_NumHeads, 2);
        printf("BPB_NumHeads     :[%d].\r\n", dbg_num);
        dbg_num = 0;
        memcpy(&dbg_num, boots->BPB_HidSec, 4);
        printf("BPB_HidSec       :[%d].\r\n", dbg_num);
        dbg_num = 0;
        memcpy(&dbg_num, boots->BPB_ToSec32, 4);
        printf("BPB_ToSec32      :[%d].\r\n", dbg_num);
        if (disk_sec == 0) {
            disk_sec = dbg_num;
        }
        printf("BS_DrvNum        :[%d].\r\n", boots->BS_DrvNum);
        printf("BS_Reserved1     :[%d].\r\n", boots->BS_Reserved1);
        printf("BS_BootSig       :[%d].\r\n", boots->BS_BootSig);
        dbg_num = 0;
        memcpy(&dbg_num, boots->BS_VolID, 4);
        printf("BS_VolID         :[%d].\r\n", dbg_num);
        memset(dbg_msg, 0, 256);
        memcpy(dbg_msg, boots->BS_VolLab, 11);
        printf("BS_VolLab        :[%s].\r\n", dbg_msg);
        memset(dbg_msg, 0, 256);
        memcpy(dbg_msg, boots->BS_FileSysType, 8);
        printf("BS_FileSysType   :[%s].\r\n", dbg_msg);
        if (memcmp("FAT12", dbg_msg, 5) == 0) {
            fat12_flg = 1;
        }
        if (memcmp("FAT16", dbg_msg, 5) == 0) {
            fat16_flg = 1;
        }
        printf("====== Boot Sector Info  End  ======\r\n");
        fat_size = fat_sec * sec_size;
        printf("FAT's size=%d.\r\n", fat_size);
        printf("fat12:%d.\r\n", fat12_flg);
        printf("fat16:%d.\r\n", fat16_flg);
        printf("fat32:%d.\r\n", fat32_flg);
    }
    if (in != NULL) {
        fclose(in);
        in = NULL;
    }
    /* 4. prepare fat */
    if (fat_size > 0) {
        pFAT = (char *) malloc(sizeof(char) * fat_size);
        if (pFAT == NULL) {
            printf("");
            flg = 1;
        }
        memset(pFAT, 0, sizeof(char)*fat_size);
        fat_idx = 0;
        if (opt_flag) {
            pFAT[fat_idx] = 0xF8;
        } else {
            pFAT[fat_idx] = 0xF0;
        }
        fat_idx ++;
        pFAT[fat_idx] = 0xFF;
        fat_idx ++;
        pFAT[fat_idx] = 0xFF;
        if (fat16_flg == 1) {
            fat_idx ++;
            pFAT[fat_idx] = 0xFF;
        }
    }
    printf("sizeof(fdt)=%d,count=%d.\r\n", sizeof(fdt), r_ent_cnt);
    r_ent_size = sizeof(fdt) * r_ent_cnt;
    if (r_ent_size > 0) {
        pr_ent = (char *) malloc(sizeof(fdt) * r_ent_cnt);
        if (pr_ent == NULL) {
            printf("root fdt memory alloc error.\r\n");
            flg = 1;
        }
        memset(pr_ent, 0, sizeof(fdt) * r_ent_cnt);
    }
    disk_size = disk_sec * sec_size;
    
    /* get input file ' s info */
    for (i = 0; (flg == 0 && i < info->in_file_cnt); i ++) {
        if (flg == 0) {
            printf("No%d file read.\r\n", i);
            in = fopen(info->in_file_name[i], "rb");
            if (in == NULL) {
                printf("in file %s open error.\r\n", info->in_file_name[i]);
                flg = 1;
                break;
            }
        }
        fseek(in, 0, SEEK_END);
        info->in_file_size[i] = ftell(in);
        printf("No%d file's size=%ld.\r\n", i, info->in_file_size[i]);
        in_file_sec = info->in_file_size[i] / (sec_size * sec_per_clus);
        if ((info->in_file_size[i] % (sec_size * sec_per_clus)) != 0) {
            in_file_sec ++;
            info->filler_size[i] = (in_file_sec * sec_size * sec_per_clus) - ((info->in_file_size[i] % 512) == 0 ? info->in_file_size[i] : ((info->in_file_size[i] / 512 ) + 1 ) * 512);
        }
        printf("No%d File's clus=%d.\r\n", i, in_file_sec, info->filler_size[i]);
        start_clus = last_sec;
        for (j = 0; j < (in_file_sec - 1); j ++) {
            last_sec ++;
            memset(obj_sec, 0, 2);
            memcpy(obj_sec, &last_sec, 2);
            /* debug printf("%02X%02X.\r\n", obj_sec[1], obj_sec[0]); */
            if (fat12_flg == 1) {
                if (fat_flg == 0) {
                    fat_idx ++;
                    pFAT[fat_idx] = obj_sec[0];
                    fat_flg = 1;
                    fat_idx ++;
                    pFAT[fat_idx] = 0x0F & obj_sec[1];
                } else if (fat_flg == 1) {
                    pFAT[fat_idx] = pFAT[fat_idx] | ((obj_sec[0] << 4) & 0xF0);
                    fat_idx ++;
                    pFAT[fat_idx] = ((obj_sec[1] << 4) & 0xF0) | ((obj_sec[0] >> 4) & 0x0F);
                    fat_flg = 0;
                }
            }
            if (fat16_flg == 1) {
                fat_idx ++;
                pFAT[fat_idx] = obj_sec[0];
                fat_idx ++;
                pFAT[fat_idx] = obj_sec[1];
            }
        }
        last_sec ++;
        memset(obj_sec, 0xFF, 2);
        printf("[FAT]%dFileEnd%02X%02X.fat12_flg=%d.fat_flg=%d.\r\n", i, obj_sec[0], obj_sec[1], fat12_flg, fat_flg);
        if (fat12_flg == 1) {
            if (fat_flg == 0) {
                fat_idx ++;
                pFAT[fat_idx] = obj_sec[0];
                fat_flg = 1;
                fat_idx ++;
                pFAT[fat_idx] = 0x0F & obj_sec[1];
            } else if (fat_flg == 1) {
                pFAT[fat_idx] = pFAT[fat_idx] | ((obj_sec[0] << 4) & 0xF0);
                fat_idx ++;
                pFAT[fat_idx] = ((obj_sec[1] << 4) & 0xF0) | ((obj_sec[0] >> 4) & 0x0F);
                fat_flg = 0;
            }
        }
        if (fat16_flg == 1) {
            fat_idx ++;
            pFAT[fat_idx] = obj_sec[0];
            fat_idx ++;
            pFAT[fat_idx] = obj_sec[1];
        }

        memset(&rfdt, 0, sizeof(fdt));
        memset(rfdt.name, ' ', 11);
        pos = -1;
        for (j = 0; j < strlen(info->in_file_name[i]); j ++) {
            if (info->in_file_name[i][j] == '.') {
                pos = j;
                break;
            }
        }
        printf("No%d File's pos=%d.\r\n", i, pos);
        if (pos >= 0) {
            memset(dbg_msg, 0, sizeof(dbg_msg));
            upper(dbg_msg, info->in_file_name[i]);
            printf("%s.\r\n", dbg_msg);

            if (pos < 8) {
                memcpy(rfdt.name, dbg_msg, pos);
                memcpy(rfdt.ex_name, dbg_msg + pos + 1, strlen(info->in_file_name[i]) - pos);
            } else {
                memcpy(rfdt.name, dbg_msg + pos - 8, 8);
                memcpy(rfdt.ex_name, dbg_msg + pos + 1, strlen(info->in_file_name[i]) - pos);
            }
        }

        rfdt.attr = 0x20;
        rfdt.crt_time_ms = 0x1D;
        yy = 1999 - 1980;
        mm = 05;
        dd = 05;
        hh = 22;
        mi = 22;
        ss = 00;
        rfdt.crt_tm[0] = (mi << 5 & 0xE0) | (ss & 0x1F);
        rfdt.crt_tm[1] = (hh << 3 & 0xF8) | (mi >> 3 & 0x07);
        rfdt.crt_dt[0] = (mm << 5 & 0xE0) | (dd & 0x1F);
        rfdt.crt_dt[1] = (yy << 1 & 0xFE) | (mm >> 3 & 0x01);
        memcpy(rfdt.lst_acs_dt, rfdt.crt_dt, 2);
        memcpy(rfdt.lst_mod_dt, rfdt.crt_dt, 2);
        memcpy(rfdt.lst_mod_tm, rfdt.crt_tm, 2);
        memcpy(rfdt.st_clus, &start_clus, 2);
        memcpy(rfdt.f_size, &info->in_file_size[i], 4);
        memcpy(pr_ent + (sizeof(fdt) * i), &rfdt, sizeof(fdt));
        if (in != NULL) {
            fclose(in);
            in = NULL;
        }
        printf("%d flag=%d.\r\n", i, flg);
    }

    /* 5.write fat1 */
    for (i = 0 ; flg == 0 && i < fat_sec; i ++) {
        wsize = fwrite(pFAT + (i  * sec_size), sizeof(char), sec_size, out);
        if (wsize != sec_size) {
            printf("fat1 write error.[%d].\r\n", wsize);
            flg = 1;
            break;
        }
    }

    /* 6.write fat2 */
    if (num_fat == 2) {
        for (i = 0 ; flg == 0 && i < fat_sec; i ++) {
            wsize = fwrite(pFAT + (i  * sec_size), sizeof(char), sec_size, out);
            if (wsize != sec_size) {
                printf("fat2 write error.[%d].\r\n", wsize);
                flg = 1;
                break;
            }
        }
    }

    /* 7.write rootdir */
    if (flg == 0 && r_ent_size > 0) {
        wsize = fwrite(pr_ent, sizeof(char), r_ent_size, out);
        if (wsize != r_ent_size) {
            printf("root fdt write error.[%d]\r\n", wsize);
            flg = 1;
        }
    }

    /* 8.write file */
    for (i = 0; (flg == 0 && i < info->in_file_cnt); i ++ ) {
        if (flg == 0) {
            printf("No %d file.\r\n", i);
            in = fopen(info->in_file_name[i], "rb");
            if (in == NULL) {
                printf("in file open error.\r\n");
                flg = 1;
                break;
            }
        }
        while(!flg && !feof(in)) {
            memset(buf, 0, READ_BYTE * sizeof(char));
            rsize = fread(buf, sizeof(char), READ_BYTE, in);
            if (rsize <= 0) {
                break;
            }
            rsize = 512;
            wsize = fwrite(buf, sizeof(char), rsize, out);
            if (wsize != rsize ) {
                printf("fwrite error.\r\n");
                flg = 1;
                break;
            }
            /* debug printf("%d wsize=%d.\r\n", i, wsize); */
        }
        for( j =0; j < info->filler_size[i]; j ++) {
            memset(dbg_msg, 0x00, sizeof(dbg_msg));
            fwrite(dbg_msg, sizeof(char), 1, out);
        }
        printf("%d filler write %d.\r\n", i, j);
        if (in != NULL) {
            fclose(in);
            in = NULL;
        }
        printf("%d flag=%d.\r\n", i, flg);
    }

    if (pr_ent != NULL) {
        free(pr_ent);
        pr_ent = NULL;
    }
    if (buf != NULL) {
        free(buf);
        buf = NULL;
    }
    if (mbrs != NULL) {
        free(mbrs);
        mbrs = NULL;
    }
    if (boots != NULL) {
        free(boots);
        boots = NULL;
    }
    /* 9.disk write */
    if (out != NULL) {
        pos = ftell(out);
        printf("output file's size:%d.\r\n", pos);
        if (disk_size > 0) {
            memset(dbg_msg, 0x00, sizeof(dbg_msg));
            for (j = 0; j < (disk_size - pos); j ++) {
                fwrite(dbg_msg, sizeof(char), 1, out);
            }
        }
        printf("output file's size:%d.\r\n", ftell(out));
        fclose(out);
        out = NULL;
    }
    if (flg == 1) {
        return -1;
    }
    return 0;
}

void get_env_info() {
    printf("sizeof(double)=%d.\r\n", sizeof(double));
    printf("sizeof(mbr)   =%d.\r\n", sizeof(mbr));
    printf("sizeof(dpt)   =%d.\r\n", sizeof(dpt));
    printf("sizeof(bs)    =%d.\r\n", sizeof(bs));
    printf("sizeof(fdt)   =%d.\r\n", sizeof(fdt));
}

char * upper(char * obj, const char * src) {
    while(*src != 0) {
        if (*src >= 97 && *src <= 122) {
            *obj = *src - 32;
        } else {
            *obj = *src;
        }
        obj ++;
        src ++;
    }
    return obj;
}
